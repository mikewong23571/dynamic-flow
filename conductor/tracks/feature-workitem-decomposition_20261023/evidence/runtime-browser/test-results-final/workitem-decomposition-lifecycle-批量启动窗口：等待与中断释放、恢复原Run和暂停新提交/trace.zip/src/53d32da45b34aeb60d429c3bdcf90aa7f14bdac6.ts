import { test, expect, type Page, type Locator } from '@playwright/test';
import { serve } from '@hono/node-server';
import type { Server } from 'node:http';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { createApplication } from '../../src/server/index.ts';
import type {
  Definition,
  Json,
  NodeExecution,
  Run,
  WorkItem,
  WorkItemView,
} from '../../src/shared/records.ts';
import { seedCatalog } from '../catalog-fixture.ts';
const evidence = resolve(
  'conductor/tracks/feature-workitem-decomposition_20261023/evidence/runtime-browser',
);
let application: Awaited<ReturnType<typeof createApplication>>,
  server: Server,
  root: string,
  url: string;
let inputs: NodeExecution['inputs'][] = [],
  agentActive = 0,
  agentPeak = 0,
  runPeak = 0;
let controlled = false;
let gates = new Map<string, Set<() => void>>();
const execute = async (ctx: NodeExecution): Promise<Json> => {
  inputs.push(structuredClone(ctx.inputs));
  agentActive++;
  agentPeak = Math.max(agentPeak, agentActive);
  try {
    if (controlled) {
      await new Promise<void>((resolve) => {
        const key = ctx.workItem!.id;
        const set = gates.get(key) ?? new Set();
        gates.set(key, set);
        const finish = () => {
          set.delete(finish);
          resolve();
        };
        set.add(finish);
        ctx.signal.addEventListener('abort', finish, { once: true });
      });
    }
    return {
      conclusion: '已核实',
      input: ctx.inputs.input.map((i) => i.value),
      evidence: '原始反馈与处理记录。'.repeat(60),
    };
  } finally {
    agentActive--;
  }
};
async function post<T>(path: string, body: unknown): Promise<T> {
  const response = await application.app.request(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  expect(response.ok, await response.clone().text()).toBeTruthy();
  return response.json() as Promise<T>;
}
async function item(id: string) {
  return application.items.get(id);
}
async function makeMethod(kind = 'review') {
  const work = await application.work.createWork(
    kind === 'summary' ? '综合确认结论' : '核查问题',
    [],
  );
  const definition: Definition = {
    schemaVersion: 1,
    inputs: ['input'],
    ...(kind === 'review'
      ? {
          inputContracts: {
            input: {
              item: {
                type: 'object',
                required: ['repository', 'ref'],
                properties: {
                  repository: { type: 'string', title: '仓库' },
                  ref: { type: 'string', title: '分支' },
                },
              },
            },
          },
        }
      : {}),
    nodes: [
      {
        id: kind,
        label: kind === 'summary' ? '形成综合报告' : '核查输入',
        kind: 'agent',
        mode: 'each',
        task: kind,
      },
    ],
    edges: [{ from: ['$input', 'input'], to: [kind, 'input'] }],
    outputs: { report: [kind, 'output'] },
  };
  const definitionId = await application.flow.saveDraft(
    work.id,
    undefined,
    definition,
  );
  return { work, definitionId, definition };
}
async function create(title: string, parentId?: string) {
  return application.items.create({
    title,
    key: title,
    goal: `完成${title}`,
    materials: [],
    ...(parentId ? { parentId } : {}),
  });
}
async function openItem(page: Page, key: string, title = key, query = key) {
  await page.goto(url);
  await page.getByRole('button', { name: '工作项', exact: true }).click();
  await page
    .getByRole('textbox', { name: '搜索工作项', exact: true })
    .fill(query);
  await page.getByRole('button', { name: '搜索', exact: true }).click();
  await page
    .getByRole('button', { name: `打开工作项 ${key}`, exact: true })
    .click();
  await expect(
    page.getByRole('heading', { name: title, exact: true }),
  ).toBeVisible();
}
const relations = (page: Page) =>
  page.getByRole('region', { name: '子项与待办' });
async function childrenTab(page: Page) {
  await page.getByRole('tab', { name: '子项', exact: true }).click();
  return relations(page);
}
async function completeUI(page: Page) {
  await page.getByRole('tab', { name: /完成条件|整体确认/ }).click();
  await expect(
    page.getByRole('button', { name: '结项', exact: true }),
  ).toBeEnabled();
  await page.getByRole('button', { name: '结项', exact: true }).click();
  await expect(
    page.getByRole('button', { name: '重新打开', exact: true }),
  ).toBeVisible();
}
async function confirmLeaf(id: string) {
  const current = await item(id);
  await application.items.criteria(id, [
    { id: 'checked', text: '核查完成', met: false, evidence: '' },
  ]);
  const updated = await item(id);
  await application.items.criteria(
    id,
    updated.criteria.map((c) => ({
      ...c,
      met: true,
      evidence: `${current.title} 已有明确结论`,
    })),
  );
  await application.items.complete(id);
}
async function adjust(
  page: Page,
  action: '移出范围' | '恢复纳入',
  reason: string,
) {
  await page.getByRole('button', { name: action, exact: true }).click();
  const dialog = page.getByRole('dialog', {
    name: action === '移出范围' ? '移出范围' : '恢复纳入范围',
    exact: true,
  });
  await dialog.getByRole('textbox', { name: '范围调整原因' }).fill(reason);
  await dialog.getByRole('button', { name: '确认调整' }).click();
}
async function endApp() {
  const current = application;
  current.runs.close();
  for (const set of gates.values()) for (const resolve of [...set]) resolve();
  await Promise.all(
    (await current.files.list()).flatMap((w) =>
      w.runs.map((r) => current.runs.wait(r.id)),
    ),
  );
}
test.beforeEach(async () => {
  root = await mkdtemp(join(tmpdir(), 'flowcraft-decomposition-lifecycle-'));
  await seedCatalog(root, {
    baseUrl: 'http://fixture.invalid',
    model: 'fixture',
    apiKey: 'fixture',
  });
  inputs = [];
  agentActive = 0;
  agentPeak = 0;
  runPeak = 0;
  controlled = false;
  gates = new Map();
  application = await createApplication({
    dataRoot: root,
    executeNode: execute,
  });
  server = serve({
    fetch: (request, env) => application.app.fetch(request, env),
    port: 0,
    hostname: '127.0.0.1',
  }) as Server;
  if (!server.listening)
    await new Promise<void>((r) => server.once('listening', r));
  url = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  await mkdir(evidence, { recursive: true });
});
test.afterEach(async () => {
  await endApp();
  server.closeAllConnections();
  await new Promise<void>((r) => server.close(() => r()));
  await rm(root, { recursive: true, force: true });
});

for (const width of [1440, 1024])
  test(`整体确认、固定汇总、排除与祖先重开 ${width}`, async ({ page }) => {
    test.setTimeout(120000);
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const quarter = await create('季度反馈'),
      target = await create('目标反馈', quarter.id),
      a = await create('仓库 A', target.id),
      b = await create('仓库 B', target.id);
    await confirmLeaf(a.id);
    await confirmLeaf(b.id);
    const firstB = (await item(b.id)).history
      .filter((h) => h.kind === 'completed')
      .at(-1)!;
    const summary = await makeMethod('summary');
    await openItem(page, '季度反馈');
    const area = await childrenTab(page);
    await area.getByRole('button', { name: /目标反馈/ }).click();
    const targetArea = await childrenTab(page);
    await expect(targetArea.getByText('已结项', { exact: true })).toHaveCount(
      2,
    );
    const conclusions = targetArea
      .locator('summary')
      .filter({ hasText: '已确认结论' });
    await expect(conclusions).toHaveCount(2);
    await targetArea
      .locator('tr')
      .filter({ has: page.getByRole('button', { name: /^仓库 A / }) })
      .locator('summary')
      .click();
    await expect(
      targetArea.getByText('仓库 A 已有明确结论', { exact: true }),
    ).toBeVisible();
    await targetArea
      .getByRole('button', { name: '汇总成果', exact: true })
      .click();
    const prepare = page.getByRole('dialog').filter({
      has: page.getByRole('heading', { name: '准备本次执行', exact: true }),
    });
    await prepare
      .getByRole('combobox', { name: '处理方法', exact: true })
      .selectOption(summary.work.id);
    await expect(
      prepare.getByRole('button', { name: /开始处理/ }),
    ).toBeEnabled();
    await prepare.getByRole('button', { name: /开始处理/ }).click();
    await expect
      .poll(async () => (await item(target.id)).execution?.status)
      .toBe('completed');
    const summaryRunId = (await item(target.id)).runs[0].runId;
    const frozen = structuredClone(
      (await application.files.read(summary.work.id)).runs.find(
        (r) => r.id === summaryRunId,
      )!.inputs,
    );
    expect(
      Object.values(frozen)
        .flat()
        .map((i) => (i.value as { itemId: string }).itemId)
        .sort(),
    ).toEqual([a.id, b.id].sort());
    await completeUI(page);
    await page.getByRole('button', { name: '返回', exact: true }).click();
    await completeUI(page);
    const oldTarget = (await item(target.id)).history
      .filter((h) => h.kind === 'completed')
      .at(-1)!;
    expect(
      oldTarget.childCompletions!.find((c) => c.itemId === b.id)!
        .completionHistoryId,
    ).toBe(firstB.id);
    await childrenTab(page);
    await area.getByRole('button', { name: /目标反馈/ }).click();
    await childrenTab(page);
    await targetArea.getByRole('button', { name: /仓库 B/ }).click();
    await page.getByRole('button', { name: '重新打开', exact: true }).click();
    const reopen = page.getByRole('dialog', {
      name: '重新打开工作项',
      exact: true,
    });
    await reopen
      .getByRole('textbox', { name: '重开原因' })
      .fill('补充新的版本证据');
    await reopen.getByRole('button', { name: '确认重开' }).click();
    const affected = page.getByRole('dialog', { name: '重新打开相关工作项' });
    await expect(affected.getByText('目标反馈', { exact: true })).toBeVisible();
    await expect(affected.getByText('季度反馈', { exact: true })).toBeVisible();
    await affected.getByRole('button', { name: '重开并继续' }).click();
    await expect.poll(async () => (await item(b.id)).status).toBe('open');
    expect((await item(target.id)).status).toBe('open');
    expect((await item(quarter.id)).status).toBe('open');
    await page.keyboard.press('Escape');
    await adjust(page, '移出范围', '本轮不含此仓库');
    await expect(
      page.getByRole('button', { name: '恢复纳入', exact: true }),
    ).toBeVisible();
    await page.getByRole('button', { name: '返回', exact: true }).click();
    await completeUI(page);
    await page.getByRole('button', { name: '返回', exact: true }).click();
    await completeUI(page);
    await childrenTab(page);
    await area.getByRole('button', { name: /目标反馈/ }).click();
    await childrenTab(page);
    await targetArea
      .getByRole('combobox', { name: '子项视图' })
      .selectOption('excluded');
    await targetArea.getByRole('button', { name: /仓库 B/ }).click();
    await adjust(page, '恢复纳入', '补齐后继续纳入');
    await expect(affected).toBeVisible();
    await affected.getByRole('button', { name: '重开并继续' }).click();
    await expect.poll(async () => (await item(target.id)).status).toBe('open');
    expect(
      (await application.files.read(summary.work.id)).runs.find(
        (r) => r.id === summaryRunId,
      )!.inputs,
    ).toEqual(frozen);
    expect(
      (await item(target.id)).history.find((h) => h.id === oldTarget.id)!
        .childCompletions,
    ).toEqual(oldTarget.childCompletions);
    await page.keyboard.press('Escape');
    await page.getByRole('button', { name: '返回', exact: true }).click();
    await childrenTab(page);
    await targetArea
      .getByRole('combobox', { name: '子项视图' })
      .selectOption('children');
    await expect(targetArea.locator('tbody tr')).toHaveCount(2);
    await page.screenshot({ path: join(evidence, `lifecycle-${width}.png`) });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBeTruthy();
  });

for (const width of [1440, 1024])
  test(`千项跨层待办筛选与返回 ${width}`, async ({ page }) => {
    test.setTimeout(180000);
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const method = await makeMethod('summary'),
      quarter = await application.items.create({
        title: '季度千项',
        key: 'SCALE-QUARTER',
        goal: '核查本季度范围',
        materials: [],
      });
    const branches: WorkItemView[] = [];
    for (let n = 0; n < 100; n++)
      branches.push(await create(`目标 ${n}`, quarter.id));
    const seed = await application.items.create({
      title: '临时历史种子',
      goal: '核查',
      materials: ['业务原文'.repeat(250)],
      workflowId: method.work.id,
    });
    const launched = await post<WorkItemView>(`/api/items/${seed.id}/actions`, {
      action: 'run',
    });
    await application.runs.wait(launched.runs[0].runId);
    const base = (await application.files.read(method.work.id)).runs[0];
    const seedItem = await item(seed.id);
    const records: WorkItem[] = [],
      runs: Run[] = [];
    for (let n = 0; n < 1000; n++) {
      const id = `scale-leaf-${n}`,
        refs = [];
      for (let k = 0; k < 4; k++) {
        const runId = `${id}-run-${k}`;
        runs.push({
          ...structuredClone(base),
          id: runId,
          workItem: {
            ...base.workItem!,
            id,
            key: id,
            title: `仓库 ${n}`,
            goal: '核查范围',
          },
          results: base.results.map((r) => ({
            ...structuredClone(r),
            id: `${id}-result-${k}`,
            runId,
            outputs: Object.fromEntries(
              Object.entries(r.outputs).map(([port, values]) => [
                port,
                values.map((value) => ({
                  ...structuredClone(value),
                  sourceResultIds: [`${id}-result-${k}`],
                })),
              ]),
            ),
          })),
        });
        refs.push({
          workId: method.work.id,
          runId,
          definitionId: method.definitionId,
        });
      }
      records.push({
        ...structuredClone(seedItem),
        id,
        key: id,
        title: `仓库 ${n}`,
        parentId: branches[n % 100].id,
        parentScope: { status: 'included', at: seedItem.createdAt },
        runs: refs,
        ...(n === 777 ? { blocker: '需要分支信息' } : {}),
        history: Array.from({ length: 20 }, (_, h) => ({
          id: `${id}-history-${h}`,
          at: seedItem.createdAt,
          kind: 'progress',
          summary: `调查${h}：` + '证据记录。'.repeat(100),
        })),
      });
    }
    await application.files.change(method.work.id, (w) => {
      w.runs.push(...runs);
    });
    for (let offset = 0; offset < 1000; offset += 100)
      await Promise.all(
        records
          .slice(offset, offset + 100)
          .map((record) =>
            writeFile(
              join(root, 'work-items', `${record.id}.json`),
              JSON.stringify(record),
            ),
          ),
      );
    // Keep the editor startup on a small method; this route evaluates the work-item workspace.
    const small = await application.work.createWork('空白方法', []);
    await page.addInitScript(
      (id) => localStorage.setItem('dynamic-flow.work', id),
      small.id,
    );
    const responses: {
      path: string;
      bytes: number;
      ms: number;
      rows?: number;
      runs?: number;
    }[] = [];
    const pending: Promise<void>[] = [];
    const pageErrors: string[] = [];
    page.on('pageerror', (e) => pageErrors.push(e.message));
    page.on('response', (response) => {
      if (
        !response.url().includes('/api/') ||
        !response.headers()['content-type']?.includes('application/json')
      )
        return;
      pending.push(
        (async () => {
          try {
            const body = await response.body(),
              parsed = JSON.parse(body.toString());
            if (response.url().includes('/api/items?'))
              expect(
                parsed.items.every(
                  (i: object) => !('history' in i) && !('materials' in i),
                ),
              ).toBeTruthy();
            responses.push({
              path:
                new URL(response.url()).pathname +
                new URL(response.url()).search,
              bytes: body.length,
              ms: response.request().timing().responseEnd,
              rows: parsed.items?.length,
              runs: parsed.work?.runs?.length,
            });
          } catch (e) {
            if (
              e instanceof Error &&
              !/closed|Protocol error|No resource/.test(e.message)
            )
              throw e;
          }
        })(),
      );
    });
    const timings = [];
    for (let pass = 0; pass < 3; pass++) {
      const before = responses.length,
        start = performance.now();
      await openItem(page, 'SCALE-QUARTER', '季度千项', '季度千项');
      const area = await childrenTab(page);
      await expect(area.locator('tbody tr')).toHaveCount(25);
      const listMs = performance.now() - start;
      if (pass === 0)
        await page.screenshot({
          path: join(evidence, `scale-page-${width}.png`),
        });
      await area
        .getByRole('combobox', { name: '子项视图' })
        .selectOption('todo');
      await area
        .getByRole('combobox', { name: '待办类型' })
        .selectOption('blocked');
      const filterStart = performance.now();
      await area
        .getByRole('textbox', { name: '搜索范围内工作项' })
        .fill('仓库 777');
      await area.getByRole('button', { name: '搜索', exact: true }).click();
      await expect(area.locator('tbody tr')).toHaveCount(1);
      await expect(area.getByText('目标 77', { exact: true })).toBeVisible();
      const filterMs = performance.now() - filterStart;
      const openStart = performance.now();
      await area.getByRole('button', { name: /仓库 777/ }).click();
      await expect(
        page.getByRole('heading', { name: '仓库 777', exact: true }),
      ).toBeVisible();
      const openMs = performance.now() - openStart;
      await page.getByRole('tab', { name: /完成条件|整体确认/ }).click();
      await page.getByRole('button', { name: '添加完成条件' }).click();
      await page
        .getByRole('textbox', { name: '条件 1', exact: true })
        .fill('尚未保存的核查范围');
      const backStart = performance.now();
      await page.getByRole('button', { name: '返回', exact: true }).click();
      await expect(
        area.getByRole('textbox', { name: '搜索范围内工作项' }),
      ).toHaveValue('仓库 777');
      await expect(area.locator('tbody tr')).toHaveCount(1);
      const backMs = performance.now() - backStart;
      await page.screenshot({
        path: join(evidence, `scale-${width}-${pass}.png`),
      });
      await Promise.all(pending);
      timings.push({
        pass,
        listMs,
        filterMs,
        openMs,
        backMs,
        requests: responses.length - before,
      });
    }
    expect(
      responses
        .filter((r) => r.path.startsWith('/api/items?'))
        .every((r) => r.rows! <= 25),
    ).toBeTruthy();
    expect(
      responses
        .filter((r) => r.path.includes(`/api/works/${method.work.id}`))
        .every((r) => r.path.includes('runIds=') && r.runs! <= 4),
    ).toBeTruthy();
    expect(pageErrors).toEqual([]);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBeTruthy();
    await writeFile(
      join(evidence, `scale-${width}.json`),
      JSON.stringify(
        {
          leafCount: 1000,
          targetCount: 100,
          historyPerLeaf: 20,
          runsPerLeaf: 4,
          timings,
          responses,
        },
        null,
        2,
      ),
    );
  });

for (const width of [1440, 1024])
  test(`批量准备十项无需配置、两项补字段 ${width}`, async ({ page }) => {
    test.setTimeout(120000);
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const method = await makeMethod(),
      parent = await application.items.create({
        title: '批量核查',
        key: 'BATCH-ROOT',
        goal: '核查全部范围',
        materials: [],
      });
    const ids: string[] = [];
    for (let n = 0; n < 12; n++) {
      const child = await application.items.create({
        title: `批量项 ${String(n + 1).padStart(2, '0')}`,
        goal: '核查目标源码',
        parentId: parent.id,
        materials: [],
        workflowId: method.work.id,
        receivedInputs: [
          {
            label: '核查对象',
            value: {
              repository: `service-${n}`,
              ...(n < 10 ? { ref: 'develop' } : {}),
            },
          },
        ],
      });
      ids.push(child.id);
    }
    let revisions = 0,
      launches = 0;
    page.on('request', (request) => {
      if (request.method() !== 'POST') return;
      const body = request.postDataJSON();
      if (body?.action === 'reviseInput') revisions++;
      if (body?.action === 'run') launches++;
    });
    await openItem(page, 'BATCH-ROOT', '批量核查');
    const area = await childrenTab(page);
    await area.getByRole('checkbox', { name: '选择本页子项' }).check();
    await area.getByRole('button', { name: '批量处理', exact: true }).click();
    let batch = page.getByRole('dialog', { name: '批量处理', exact: true });
    await batch.getByRole('button', { name: '准备输入' }).click();
    await expect(batch.getByText('可启动 10', { exact: true })).toBeVisible();
    await expect(batch.getByText('需补充 2', { exact: true })).toBeVisible();
    for (const n of [11, 12]) {
      const row = batch.getByRole('row').filter({ hasText: `批量项 ${n}` });
      await row.getByRole('button', { name: '查看', exact: true }).click();
      await page
        .getByRole('button', { name: '运行流水线', exact: true })
        .click();
      const prepare = page.getByRole('dialog').filter({
        has: page.getByRole('heading', { name: '准备本次执行', exact: true }),
      });
      await expect(
        prepare.getByRole('combobox', { name: '处理方法', exact: true }),
      ).toHaveValue(method.work.id);
      await prepare
        .getByRole('button', { name: '补齐／修正输入', exact: true })
        .click();
      const revise = page.getByRole('dialog', { name: '修正输入 · 核查对象' });
      await revise
        .getByRole('textbox', { name: '分支', exact: true })
        .fill('develop');
      await revise
        .getByRole('button', { name: '保存修订', exact: true })
        .click();
      await expect(revise).not.toBeVisible();
      await page.keyboard.press('Escape');
      await page.getByRole('button', { name: '返回', exact: true }).click();
      batch = page.getByRole('dialog', { name: '批量处理', exact: true });
      if (!(await batch.isVisible())) {
        await childrenTab(page);
        await area
          .getByRole('button', { name: '批量处理', exact: true })
          .click();
      }
      await batch.getByRole('button', { name: '准备输入' }).click();
      await expect(
        batch.getByText(`可启动 ${n}`, { exact: true }),
      ).toBeVisible();
    }
    await expect(batch.getByText('需补充 0', { exact: true })).toBeVisible();
    await batch.getByRole('button', { name: '启动就绪项' }).click();
    await expect(batch.getByText('已启动 12', { exact: true })).toBeVisible({
      timeout: 30000,
    });
    await expect
      .poll(async () => {
        const values = await Promise.all(ids.map(item));
        return values.filter((i) => i.execution?.status === 'completed').length;
      })
      .toBe(12);
    expect(revisions).toBe(2);
    expect(launches).toBe(12);
    expect(
      (await Promise.all(ids.map(item))).every((i) => i.runs.length === 1),
    ).toBeTruthy();
    await expect(
      batch.getByRole('button', { name: '启动就绪项' }),
    ).toBeVisible();
    await expect(
      batch.getByRole('button', { name: '启动就绪项' }),
    ).toBeDisabled();
    await page.screenshot({
      path: join(evidence, `batch-inputs-${width}.png`),
    });
    await writeFile(
      join(evidence, `batch-inputs-${width}.json`),
      JSON.stringify(
        {
          completeInputs: 10,
          missingInputs: 2,
          inputRevisions: revisions,
          individualMappings: 0,
          launches,
          agentPeak,
        },
        null,
        2,
      ),
    );
  });

test('批量启动窗口：等待与中断释放、恢复原Run和暂停新提交', async ({
  page,
  context,
}) => {
  test.setTimeout(180000);
  controlled = true;
  const parent = await create('有等待的批次');
  const work = await application.work.createWork('等待或直接核查', []);
  const definition: Definition = {
    schemaVersion: 1,
    inputs: ['input'],
    nodes: [
      {
        id: 'branch',
        label: '选择处理路径',
        kind: 'branch',
        mode: 'all',
        condition: { field: 'wait', operator: 'equals', value: true },
      },
      {
        id: 'wait',
        label: '等待补充',
        kind: 'wait',
        mode: 'all',
        wait: { event: 'ready', reason: '等待资料' },
      },
      {
        id: 'after',
        label: '资料到齐后核查',
        kind: 'agent',
        mode: 'each',
        concurrency: 2,
        task: '核查',
      },
      {
        id: 'direct',
        label: '直接核查',
        kind: 'agent',
        mode: 'each',
        concurrency: 2,
        task: '核查',
      },
    ],
    edges: [
      { from: ['$input', 'input'], to: ['branch', 'input'] },
      { from: ['branch', 'matched'], to: ['wait', 'input'] },
      { from: ['wait', 'output'], to: ['after', 'input'] },
      { from: ['branch', 'unmatched'], to: ['direct', 'input'] },
    ],
    outputs: { waited: ['after', 'output'], direct: ['direct', 'output'] },
  };
  const definitionId = await application.flow.saveDraft(
    work.id,
    undefined,
    definition,
  );
  const children: WorkItemView[] = [];
  for (let n = 0; n < 8; n++)
    children.push(
      await application.items.create({
        title: `窗口项 ${String.fromCharCode(65 + n)}`,
        key: `WINDOW-${n}`,
        goal: '核查',
        parentId: parent.id,
        workflowId: work.id,
        materials: [],
        receivedInputs: [0, 1].map((i) => ({
          label: `目标${i}`,
          value: { wait: n < 2, index: i },
        })),
      }),
    );
  // Stable row order is part of this explicit fixture, independent of UUID tie-breaking.
  for (let n = 0; n < children.length; n++) {
    const child = await item(children[n].id);
    child.progressAt = new Date(Date.UTC(2026, 0, 20 - n)).toISOString();
    await writeFile(
      join(root, 'work-items', `${child.id}.json`),
      JSON.stringify(child),
    );
  }
  const activeCount = async () => {
    const states = (await application.files.read(work.id)).runs.map(
      (r) => r.status,
    );
    const active = states.filter((s) =>
      ['queued', 'running', 'stopping'].includes(s),
    ).length;
    runPeak = Math.max(runPeak, active);
    return active;
  };
  await openItem(page, parent.key);
  const area = await childrenTab(page);
  await area.getByRole('checkbox', { name: '选择本页子项' }).check();
  await area.getByRole('button', { name: '批量处理', exact: true }).click();
  const batch = page.getByRole('dialog', { name: '批量处理', exact: true });
  await batch.getByRole('button', { name: '准备输入' }).click();
  await expect(batch.getByText('可启动 8', { exact: true })).toBeVisible();
  await batch.getByRole('button', { name: '启动就绪项' }).click();
  await expect
    .poll(async () => (await application.files.read(work.id)).runs.length)
    .toBe(4);
  await expect
    .poll(async () => (await item(children[0].id)).execution?.status)
    .toBe('waiting');
  await expect
    .poll(async () => (await item(children[1].id)).execution?.status)
    .toBe('waiting');
  expect(await activeCount()).toBe(2);
  const originalIds = (
    await Promise.all(children.slice(0, 4).map((c) => item(c.id)))
  ).map((i) => i.runs[0].runId);
  // Recreate the application over the same files: explicit application recovery, not a child-process test.
  await endApp();
  application = await createApplication({
    dataRoot: root,
    executeNode: execute,
  });
  await expect
    .poll(async () => (await item(children[2].id)).execution?.status)
    .toBe('interrupted');
  await expect
    .poll(async () => (await application.files.read(work.id)).runs.length)
    .toBe(6);
  expect(await activeCount()).toBe(2);
  const operator = await context.newPage();
  await openItem(operator, children[2].key, children[2].title);
  await operator.getByRole('button', { name: '继续执行', exact: true }).click();
  await expect
    .poll(async () => (await item(children[2].id)).execution?.status)
    .toBe('running');
  expect((await item(children[2].id)).runs[0].runId).toBe(originalIds[2]);
  expect(await activeCount()).toBe(3);
  await openItem(operator, children[0].key, children[0].title);
  await operator.getByRole('button', { name: '发送事件', exact: true }).click();
  const signal = operator.getByRole('dialog', {
    name: '发送事件',
    exact: true,
  });
  await signal.getByRole('button', { name: '发送事件', exact: true }).click();
  await expect
    .poll(async () => (await item(children[0].id)).execution?.status)
    .toBe('running');
  expect((await item(children[0].id)).runs[0].runId).toBe(originalIds[0]);
  expect(await activeCount()).toBe(4);
  await expect(batch.getByText('已启动 6', { exact: true })).toBeVisible();
  await page.waitForTimeout(1200);
  expect((await application.files.read(work.id)).runs).toHaveLength(6);
  await batch.getByRole('button', { name: '暂停启动', exact: true }).click();
  for (const set of gates.values()) for (const release of [...set]) release();
  await expect.poll(activeCount).toBe(0);
  await page.waitForTimeout(1200);
  expect((await application.files.read(work.id)).runs).toHaveLength(6);
  expect((await item(children[6].id)).runs).toHaveLength(0);
  expect((await item(children[7].id)).runs).toHaveLength(0);
  for (const title of ['窗口项 A', '窗口项 C', '窗口项 E', '窗口项 F'])
    await expect(
      batch
        .getByRole('row')
        .filter({ hasText: title })
        .getByRole('cell', { name: '已完成', exact: true }),
    ).toBeVisible();
  await page.screenshot({ path: join(evidence, 'batch-window.png') });
  await writeFile(
    join(evidence, 'batch-window.json'),
    JSON.stringify(
      {
        newStartLimit: 2,
        waitingReleased: 2,
        interruptedReleased: 2,
        resumeUsesOriginalRun: true,
        signalUsesOriginalRun: true,
        runPeak,
        agentPeak,
        submittedRuns: 6,
        pausedUnsubmitted: 2,
      },
      null,
      2,
    ),
  );
  await operator.close();
});
