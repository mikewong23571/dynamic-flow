import { test, expect, type Locator, type Page } from '@playwright/test';
import { serve } from '@hono/node-server';
import type { Server } from 'node:http';
import { mkdtemp, mkdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { createApplication } from '../../src/server/index';
import type { Definition, WorkItemView } from '../../src/shared/records';
import type { ItemWorkspace } from '../../src/shared/workitem-composition';
import { seedCatalog } from '../catalog-fixture';

// Independent review routes. Serve the current dist with real application HTTP,
// runtime and temporary persistence; only Assistant prose is an explicit fixture.
let application: Awaited<ReturnType<typeof createApplication>>;
let server: Server;
let dataRoot: string;
let url: string;
let browserErrors: string[];
const evidence = resolve(
  process.env.FLOWCRAFT_EVIDENCE_DIR ||
    'test-results/composition-review-evidence',
);
const longReply =
  Array.from(
    { length: 48 },
    (_, index) =>
      `核对记录 ${index + 1}：这是一段明确的测试会话，用于检查长消息后的输入位置和未发送草稿保留。`,
  ).join('\n\n') + '\n\n独立长会话结束标记';
const identity: Definition = {
  schemaVersion: 1,
  inputs: ['materials'],
  nodes: [
    {
      id: 'read',
      label: '读取最初材料',
      kind: 'function',
      mode: 'each',
      operation: 'map',
      functionName: 'identity',
    },
  ],
  edges: [{ from: ['$input', 'materials'], to: ['read', 'input'] }],
  outputs: { original: ['read', 'output'] },
};
const waiting: Definition = {
  schemaVersion: 1,
  inputs: ['materials'],
  nodes: [
    {
      id: 'wait',
      label: '等待资料确认',
      kind: 'wait',
      mode: 'all',
      wait: { event: 'review.ready', reason: '等待负责人确认原始资料' },
    },
  ],
  edges: [{ from: ['$input', 'materials'], to: ['wait', 'input'] }],
  outputs: { confirmation: ['wait', 'output'] },
};

test.beforeEach(async ({ page }) => {
  dataRoot = await mkdtemp(join(tmpdir(), 'composition-independent-review-'));
  browserErrors = [];
  page.on('pageerror', (error) => browserErrors.push(error.message));
  await seedCatalog(dataRoot, {
    baseUrl: 'http://fixture.invalid',
    model: 'explicit-review-fixture',
    apiKey: 'fixture-not-real',
  });
  application = await createApplication({
    dataRoot,
    runSession: async () => longReply,
  });
  server = serve({
    fetch: application.app.fetch,
    hostname: '127.0.0.1',
    port: 0,
  }) as Server;
  if (!server.listening)
    await new Promise<void>((done) => server.once('listening', done));
  url = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  await mkdir(evidence, { recursive: true });
});
test.afterEach(async () => {
  application?.batches.close();
  application?.runs.close();
  if (server) {
    server.closeAllConnections();
    await new Promise<void>((done) => server.close(() => done()));
  }
  if (dataRoot) await rm(dataRoot, { recursive: true, force: true });
  expect(browserErrors).toEqual([]);
});

async function post<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(url + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await response.text();
  expect(response.ok, `${path}: ${text}`).toBeTruthy();
  return JSON.parse(text) as T;
}
async function createItem(title: string, fields: Record<string, unknown> = {}) {
  return post<WorkItemView>('/api/items', {
    title,
    goal: `按明确依据完成${title}`,
    materials: ['本项独立原始资料'],
    criteria: [],
    ...fields,
  });
}
async function act(id: string, fields: Record<string, unknown>) {
  return post<WorkItemView>(`/api/items/${id}/actions`, fields);
}
async function workspace(id: string, fields: Record<string, unknown>) {
  return post<ItemWorkspace>(`/api/items/${id}/workspace/actions`, fields);
}
async function confirmLeaf(item: WorkItemView) {
  const saved = await act(item.id, {
    action: 'criteria',
    criteria: [
      { id: 'reviewed', text: '资料有明确核对结论', met: false, evidence: '' },
    ],
  });
  await act(item.id, {
    action: 'criteria',
    criteria: saved.criteria.map((criterion) => ({
      ...criterion,
      met: true,
      evidence: '人工核查本项资料，结论及来源可检查。',
    })),
  });
  await act(item.id, { action: 'complete' });
}
async function openItem(page: Page, item: WorkItemView) {
  await page.goto(url);
  await page.getByRole('button', { name: '工作项', exact: true }).click();
  await page
    .getByRole('textbox', { name: '搜索工作项', exact: true })
    .fill(item.key);
  await page.getByRole('button', { name: '搜索', exact: true }).click();
  await page
    .getByRole('button', { name: `打开工作项 ${item.key}`, exact: true })
    .click();
  await expect(
    page.getByRole('heading', { name: item.title, exact: true }),
  ).toBeVisible();
}
async function acceptance(page: Page) {
  await page
    .getByRole('button', { name: /^完成条件/ })
    .first()
    .click();
  const dialog = page.getByRole('dialog', { name: '完成条件', exact: true });
  await expect(dialog).toBeVisible();
  return dialog;
}
async function visibleInsideViewport(locator: Locator) {
  await expect(locator).toBeVisible();
  await expect
    .poll(async () =>
      locator.evaluate((element) => {
        const rect = element.getBoundingClientRect();
        return (
          rect.top >= 0 &&
          rect.left >= 0 &&
          rect.right <= innerWidth &&
          rect.bottom <= innerHeight
        );
      }),
    )
    .toBeTruthy();
}
async function capture(page: Page, name: string) {
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBeTruthy();
  await page.screenshot({ path: join(evidence, `${name}.png`) });
}

for (const width of [1440, 1024]) {
  test(`独立复核：直接输入和长会话后仍可继续 ${width}`, async ({ page }) => {
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const item = await createItem('直接描述当前任务');
    await openItem(page, item);
    const composer = page.getByRole('textbox', {
      name: '对话修改',
      exact: true,
    });
    await visibleInsideViewport(composer);
    await expect(composer).toBeEnabled();
    await composer.fill('请先核对需求中的缺口，不修改流程。');
    await capture(page, `review-direct-input-${width}`);
    await composer.press('Control+Enter');
    await expect(
      page.getByText('独立长会话结束标记', { exact: false }),
    ).toBeVisible();
    await visibleInsideViewport(composer);
    await composer.fill('尚未发送的下一步需求');
    await page
      .getByRole('button', { name: '收起工作项 Assistant', exact: true })
      .click();
    await visibleInsideViewport(composer);
    await expect(composer).toHaveValue('尚未发送的下一步需求');
    await page
      .getByRole('button', { name: '展开工作项 Assistant', exact: true })
      .click();
    await visibleInsideViewport(composer);
    await expect(composer).toHaveValue('尚未发送的下一步需求');
    await page.getByRole('tab', { name: '输入', exact: true }).click();
    await expect(composer).toHaveValue('尚未发送的下一步需求');
    await capture(page, `review-long-assistant-${width}`);
    const saved = await application.items.get(item.id);
    expect(saved.compositionWorkId).toBeTruthy();
    const privateWork = await application.files.read(saved.compositionWorkId!);
    expect(
      privateWork.messages.filter((message) => message.role === 'user'),
    ).toHaveLength(1);
    expect(
      privateWork.messages.find((message) => message.role === 'user')?.text,
    ).toBe('请先核对需求中的缺口，不修改流程。');
  });

  test(`独立复核：结构父项、子项入口和验收错误保留 ${width}`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const parent = await createItem('无需自身条件的整体确认');
    const first = await createItem('已确认的独立子项', { parentId: parent.id });
    const second = await createItem('等待人工确认的子项', {
      parentId: parent.id,
    });
    await confirmLeaf(first);
    await openItem(page, parent);
    let dialog = await acceptance(page);
    await expect(dialog).toContainText('1/2');
    await expect(
      dialog.getByRole('button', { name: '确认结项', exact: true }),
    ).toBeDisabled();
    await dialog.getByRole('button', { name: '检查子项', exact: true }).click();
    const children = page.getByRole('dialog', {
      name: '子工作项',
      exact: true,
    });
    await expect(
      children.getByRole('button', { name: '添加子项', exact: true }),
    ).toBeVisible();
    await children
      .getByRole('button', { name: second.title, exact: false })
      .click();
    await expect(
      page.getByRole('heading', { name: second.title, exact: true }),
    ).toBeVisible();
    await page
      .getByRole('button', { name: /返回工作项/ })
      .first()
      .click();
    await expect(
      page.getByRole('heading', { name: parent.title, exact: true }),
    ).toBeVisible();
    await confirmLeaf(second);
    dialog = await acceptance(page);
    await expect(dialog).toContainText('2/2');
    await expect(
      dialog.getByRole('textbox', { name: /^完成条件 \d/ }),
    ).toHaveCount(0);
    await expect(
      dialog.getByRole('button', { name: '确认结项', exact: true }),
    ).toBeEnabled();
    await capture(page, `review-structural-acceptance-${width}`);
    await dialog.getByRole('button', { name: '确认结项', exact: true }).click();
    await expect
      .poll(async () => (await application.items.get(parent.id)).status)
      .toBe('completed');

    // A real concurrent write invalidates the editor's starting revision.
    // The submitted draft and error must remain inside the same modal.
    const conflict = await createItem('保留验收草稿', {
      criteria: ['原完成条件'],
    });
    await openItem(page, conflict);
    dialog = await acceptance(page);
    const condition = dialog.getByRole('textbox', {
      name: '完成条件 1',
      exact: true,
    });
    await condition.fill('这条修改在失败后仍应保留');
    await act(conflict.id, {
      action: 'addEvidence',
      materials: ['另一入口新补充的事实'],
    });
    await dialog.getByRole('button', { name: '保存条件', exact: true }).click();
    await expect(dialog.getByRole('alert')).toBeVisible();
    await expect(condition).toHaveValue('这条修改在失败后仍应保留');
    expect((await application.items.get(conflict.id)).criteria[0].text).toBe(
      '原完成条件',
    );
    await visibleInsideViewport(
      dialog.getByRole('button', { name: '保存条件', exact: true }),
    );
    await capture(page, `review-modal-conflict-${width}`);
  });

  test(`独立复核：跨方法历史与同次等待事件 ${width}`, async ({ page }) => {
    await page.setViewportSize({ width, height: width === 1440 ? 900 : 768 });
    const method = await application.work.createWork('最初资料阅读方法', []);
    const definitionId = await application.flow.saveDraft(
      method.id,
      undefined,
      identity,
    );
    await application.flow.adopt(method.id, definitionId);
    const item = await createItem('跨方法持续跟进', { workflowId: method.id });
    await act(item.id, { action: 'run', definitionId });
    await expect
      .poll(
        async () => (await application.items.get(item.id)).execution?.status,
      )
      .toBe('completed');
    const original = (await application.items.get(item.id)).runs[0];
    let current = await workspace(item.id, { action: 'init' });
    current = await workspace(item.id, {
      action: 'saveFlow',
      baseRevision: current.item.revision,
      definition: waiting,
    });
    await workspace(item.id, {
      action: 'run',
      baseRevision: current.item.revision,
    });
    await expect
      .poll(
        async () => (await application.items.get(item.id)).execution?.status,
      )
      .toBe('waiting');
    const pending = await application.items.get(item.id);
    expect(pending.runs).toHaveLength(2);
    const waitingRunId = pending.execution!.runId;
    await openItem(page, pending);
    await page.getByRole('tab', { name: '记录', exact: true }).click();
    await expect(
      page.getByRole('button', { name: /第 1 轮.*查看执行/ }),
    ).toBeVisible();
    await expect(
      page.getByRole('button', { name: /第 2 轮.*查看执行/ }),
    ).toBeVisible();
    const snapshotResponse = page.waitForResponse(
      (response) =>
        response.url().includes(`/api/works/${original.workId}`) &&
        response.request().method() === 'GET',
    );
    await page.getByRole('button', { name: /第 1 轮.*查看执行/ }).click();
    await snapshotResponse;
    await expect(page.locator('.run-inspector')).toBeVisible();
    await expect(page.locator('.run-inspector')).toContainText('读取最初材料');
    await page.getByRole('button', { name: '工作项', exact: true }).click();
    await page.getByRole('tab', { name: '流程', exact: true }).click();
    await expect(
      page.getByText('等待负责人确认原始资料', { exact: false }).first(),
    ).toBeVisible();
    await page.getByRole('button', { name: '提交事件', exact: true }).click();
    const signal = page.getByRole('dialog', {
      name: '提交等待事件',
      exact: true,
    });
    await signal
      .getByRole('textbox', { name: '事件', exact: true })
      .fill('wrong.event');
    await signal.getByRole('button', { name: '提交事件', exact: true }).click();
    await expect(signal.getByRole('alert')).toBeVisible();
    await expect(
      signal.getByRole('textbox', { name: '事件', exact: true }),
    ).toHaveValue('wrong.event');
    expect((await application.items.get(item.id)).execution?.status).toBe(
      'waiting',
    );
    await capture(page, `review-wait-error-${width}`);
    await signal
      .getByRole('textbox', { name: '事件', exact: true })
      .fill('review.ready');
    await signal.getByRole('button', { name: '提交事件', exact: true }).click();
    await expect(signal).toBeHidden();
    await expect
      .poll(
        async () => (await application.items.get(item.id)).execution?.status,
      )
      .toBe('completed');
    const finished = await application.items.get(item.id);
    expect(finished.execution?.runId).toBe(waitingRunId);
    expect(finished.runs).toHaveLength(2);
    expect(finished.status).toBe('open');
    await capture(page, `review-wait-continued-${width}`);
  });
}
